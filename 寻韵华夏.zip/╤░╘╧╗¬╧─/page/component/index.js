Page({
  data: {
    imgUrls: [
      'https://img.zcool.cn/community/011e2e57b088950000012e7e0941cc.jpg@2o.jpg',
      'https://img95.699pic.com/photo/50042/6858.jpg_wh860.jpg',
      'https://pic4.zhimg.com/v2-7ad86e1e28b1f49feec58ceb70729b3a_1440w.jpg'
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 3000,
    duration: 800,
      go2detail:function(){
    wx.switchTab({
      url: '/page/component/tour/tour',
    })
  },
  }
})